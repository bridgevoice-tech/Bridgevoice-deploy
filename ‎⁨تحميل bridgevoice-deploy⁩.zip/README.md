# BridgeVoice Deployment

This repository contains the deployment files for the BridgeVoice platform on Vercel.